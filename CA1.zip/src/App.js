import logo from './logo.svg';
import './App.css';
import RegisterForm from './components/dynamic';
function App() {
  return (
    <div className="App">
      <RegisterForm />
    </div>
  );
}

export default App;
